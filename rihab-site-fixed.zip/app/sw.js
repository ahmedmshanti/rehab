/* رحاب القرآن — Service Worker
   لإصدار تحديث: غيّر قيمة VERSION هنا (وفي version.json) ثم ارفع الملفات. */
const VERSION = '1.0.1';
const CACHE = 'rihab-' + VERSION;
const PRECACHE = ['./', './index.html', './manifest.json', './icons/icon-192.png', './icons/icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(PRECACHE)).catch(() => {}));
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k.startsWith('rihab-') && k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('message', e => { if (e.data === 'SKIP_WAITING') self.skipWaiting(); });

self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return; // Supabase وغيره: مباشرة من الشبكة
  if (url.pathname.endsWith('/sw.js') || url.pathname.endsWith('/version.json')) return;
  if (req.mode === 'navigate') {            // الصفحة: الشبكة أولاً، وإن لم يوجد إنترنت فالنسخة المحفوظة
    e.respondWith(
      fetch(req).then(r => { caches.open(CACHE).then(c => c.put('./index.html', r.clone())); return r; })
        .catch(() => caches.match('./index.html'))
    );
    return;
  }
  e.respondWith(                            // بقية الملفات: من الكاش ثم تحديثها بالخلفية
    caches.match(req).then(hit => {
      const net = fetch(req).then(r => { if (r.ok) caches.open(CACHE).then(c => c.put(req, r.clone())); return r; }).catch(() => hit);
      return hit || net;
    })
  );
});
