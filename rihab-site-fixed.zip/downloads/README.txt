ضع هنا ملف التطبيق باسم:  rihab-alquran.apk
(انظر دليل-الإعداد.md لطريقة إنشائه من PWABuilder)
